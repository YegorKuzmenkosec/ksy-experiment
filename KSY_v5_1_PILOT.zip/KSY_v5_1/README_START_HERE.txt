KSY v5.1 PILOT

Откройте index.html в Chrome. 6 заданий на участника: по одному Grouped и Distributed на каждый уровень A/B/C. После завершения скачайте CSV.

Для Qwen: pip3 install requests; ollama pull qwen3:8b; python3 run_qwen.py (Ollama должна быть запущена).

Не показывайте участникам answer_key_RESEARCHER_ONLY.csv. Не смешивайте результаты разных версий.

Это пилот. Точность и время на маленькой выборке не доказывают гипотезу.
