KSY v5.1 — česká verze.
Účastníci: otevřete index.html v prohlížeči, dokončete 6 úloh a stáhněte CSV.
Výzkumník: stimuli.json obsahuje všechny scénáře; answer_key_RESEARCHER_ONLY.csv nesdílejte s účastníky.
LLM: python3 -m pip install requests; spusťte Ollama s modelem qwen3:8b; potom python3 run_qwen.py.
Nemíchejte výsledky české a ruské verze bez označení jazyka.
