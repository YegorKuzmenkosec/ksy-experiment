"""Run exactly the same v5.1 scenarios in Ollama qwen3:8b. Requires requests."""
import argparse,csv,json,random,time
from pathlib import Path
import requests
p=Path(__file__).parent
ap=argparse.ArgumentParser()
ap.add_argument('--model',default='qwen3:8b')
ap.add_argument('--url',default='http://localhost:11434/api/generate')
ap.add_argument('--output',default='qwen_v5_1_cz_results.csv')
a=ap.parse_args()
stim=json.loads((p/'stimuli.json').read_text())
rows=[]
for s in stim:
 for cond in ('grouped','distributed'):
  prompt='Přečti si text a odpověz na otázku výběrem právě jedné z uvedených možností. Napiš pouze přesné znění vybrané odpovědi bez vysvětlení.\n\n'+'\n'.join(s[cond])+'\n\nOTÁZKA: '+s['question']+'\nMOŽNOSTI: '+' | '.join(s['options'])
  t=time.perf_counter()
  r=requests.post(a.url,json={'model':a.model,'prompt':prompt,'stream':False,'options':{'temperature':0}},timeout=300)
  r.raise_for_status();answer=r.json().get('response','').strip()
  row={'scenario':s['id'],'level':s['level'],'condition':cond,'answer':answer,'correct_answer':s['answer'],'correct':int(answer==s['answer']),'response_ms':round((time.perf_counter()-t)*1000)}
  rows.append(row);print(s['id'],cond,'OK' if row['correct'] else 'WRONG',flush=True)
with (p/a.output).open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print('Saved',p/a.output)
